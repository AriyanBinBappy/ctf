#!/bin/bash

echo "[*] Updating system..."
sudo apt update -y && sudo apt upgrade -y

echo "[*] Installing Python 3, pip, and MySQL server..."
sudo apt install -y python3 python3-pip mysql-server

echo "[*] Starting and enabling MySQL..."
sudo systemctl start mariadb
sudo systemctl enable mariadb

echo "[*] Securing MySQL (skipped interactive for auto setup)..."
sudo mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'rootpass'; FLUSH PRIVILEGES;"

echo "[*] Creating MySQL CTF user..."
sudo mysql -uroot -prootpass -e "CREATE USER IF NOT EXISTS 'ctfuser'@'localhost' IDENTIFIED BY 'ctfpass';"
sudo mysql -uroot -prootpass -e "GRANT ALL PRIVILEGES ON *.* TO 'ctfuser'@'localhost' WITH GRANT OPTION;"
sudo mysql -uroot -prootpass -e "FLUSH PRIVILEGES;"

echo "[*] Installing Python dependencies..."
pip3 install flask pymysql

echo "[*] Exporting environment variables for your Python script..."
export DB_USER='ctfuser'
export DB_PASS='ctfpass'
export DB_HOST='localhost'
export DB_NAME='schooldb'
export DB_PORT=3306

echo "[*] Setup complete!"
echo "[*] Launching school_ctf.py (make sure it's in the same folder)..."

python3 school_ctf.py
