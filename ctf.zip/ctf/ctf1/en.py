from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import base64
import secrets

backend = default_backend()

# Use a fixed 32-byte key (change this key for your own lab)
KEY = b'octo_dark_cyber_secret_key_32bytes!!'[:32]

def pkcs7_pad(data: bytes) -> bytes:
    pad_len = 16 - (len(data) % 16)
    return data + bytes([pad_len] * pad_len)

def encrypt_flag(flag_str: str) -> str:
    iv = secrets.token_bytes(16)
    cipher = Cipher(algorithms.AES(KEY), modes.CBC(iv), backend=backend)
    encryptor = cipher.encryptor()
    padded_flag = pkcs7_pad(flag_str.encode())
    ciphertext = encryptor.update(padded_flag) + encryptor.finalize()
    encrypted_data = iv + ciphertext
    return base64.b64encode(encrypted_data).decode()

if __name__ == "__main__":
    flag = "flag{Tor_nani_er_sauya}"
    encrypted_flag = encrypt_flag(flag)
    print("Encrypted flag:")
    print(encrypted_flag)
