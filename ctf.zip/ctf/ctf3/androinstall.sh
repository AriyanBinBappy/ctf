pkg install python
pip install flask pymysql

# Use remote MySQL running on Kali
export DB_HOST='192.168.0.101'  # your Kali IP
export DB_USER='root'
export DB_PASS='your_mysql_password'
export DB_PORT=3306

python3 school_ctf.py
