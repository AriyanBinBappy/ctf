import os
import sqlite3
import subprocess
from flask import Flask, render_template_string, request, redirect, url_for, session, flash, send_from_directory
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'supersecretkey!change_this'
app.config['UPLOAD_FOLDER'] = './uploads'
app.config['BACKEND_FOLDER'] = './backend'
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024  # 2MB limit

if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

if not os.path.exists(app.config['BACKEND_FOLDER']):
    os.makedirs(app.config['BACKEND_FOLDER'])

# Place your flag in backend folder
flag_path = os.path.join(app.config['BACKEND_FOLDER'], 'flag.txt')
if not os.path.exists(flag_path):
    with open(flag_path, 'w') as f:
        f.write('FLAG{ODCSCTF_Reverse_Shell_Complete}')

# --- Database setup ---
def init_db():
    conn = sqlite3.connect('school.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS admin (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT
        )
    ''')
    c.execute('DELETE FROM admin')  # reset
    c.execute("INSERT INTO admin (username,password) VALUES ('admin','admin123')")

    c.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            class TEXT,
            roll_no INTEGER,
            email TEXT,
            attendance REAL
        )
    ''')

    c.execute('''
        CREATE TABLE IF NOT EXISTS teachers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            subject TEXT,
            email TEXT,
            class_assigned TEXT
        )
    ''')

    c.execute('DELETE FROM students')
    students = [
        ('Aarav Sharma', '10', 101, 'aarav.sharma@example.com', 92.5),
        ('Priya Verma', '12', 202, 'priya.verma@example.com', 88.0),
        ('Rahul Nair', '11', 150, 'rahul.nair@example.com', 95.2),
        ('Sneha Gupta', '9', 110, 'sneha.gupta@example.com', 89.5),
        ('Aditya Singh', '12', 205, 'aditya.singh@example.com', 94.0)
    ]
    c.executemany('INSERT INTO students (name,class,roll_no,email,attendance) VALUES (?,?,?,?,?)', students)

    c.execute('DELETE FROM teachers')
    teachers = [
        ('Anita Kapoor', 'Mathematics', 'anita.kapoor@example.com', '10'),
        ('Vikram Mehta', 'Science', 'vikram.mehta@example.com', '11'),
        ('Rina Das', 'English', 'rina.das@example.com', '9'),
        ('Suresh Patel', 'Computer', 'suresh.patel@example.com', '12'),
        ('Neha Joshi', 'Physics', 'neha.joshi@example.com', '10')
    ]
    c.executemany('INSERT INTO teachers (name,subject,email,class_assigned) VALUES (?,?,?,?)', teachers)

    conn.commit()
    conn.close()

init_db()

# --- Vulnerable admin login (SQLi) ---
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username','')
        password = request.form.get('password','')

        # SQL Injection vulnerable query: DO NOT sanitize inputs
        query = f"SELECT * FROM admin WHERE username = '{username}' AND password = '{password}'"
        conn = sqlite3.connect('school.db')
        c = conn.cursor()
        try:
            c.execute(query)
            user = c.fetchone()
        except Exception as e:
            flash('Database error: ' + str(e))
            user = None
        conn.close()

        if user:
            session['admin'] = user[1]
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid credentials')
    return render_template_string('''
    <!doctype html>
    <html lang="en">
    <head>
      <title>Admin Login - Octo Dark Cyber Squad School</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light d-flex align-items-center" style="height:100vh;">
    <div class="container col-md-4">
      <h3 class="mb-4 text-center">Admin Login</h3>
      {% with messages = get_flashed_messages() %}
        {% if messages %}
          <div class="alert alert-danger">{{ messages[0] }}</div>
        {% endif %}
      {% endwith %}
      <form method="post">
        <div class="mb-3">
          <label>Username</label>
          <input type="text" name="username" class="form-control" required autofocus>
        </div>
        <div class="mb-3">
          <label>Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <button class="btn btn-primary w-100" type="submit">Login</button>
      </form>
      <small class="text-muted mt-3 d-block text-center">
        Hint: SQLi </code>
      </small>
    </div>
    </body>
    </html>
    ''')

# --- Admin dashboard ---
@app.route('/admin/dashboard')
def admin_dashboard():
    if 'admin' not in session:
        return redirect(url_for('admin_login'))

    conn = sqlite3.connect('school.db')
    c = conn.cursor()

    c.execute('SELECT COUNT(*) FROM students')
    total_students = c.fetchone()[0]
    c.execute('SELECT COUNT(*) FROM teachers')
    total_teachers = c.fetchone()[0]
    c.execute("SELECT COUNT(DISTINCT class) FROM students")
    total_classes = c.fetchone()[0]
    c.execute('SELECT AVG(attendance) FROM students')
    avg_attendance = c.fetchone()[0] or 0

    c.execute('SELECT * FROM students')
    students = c.fetchall()
    c.execute('SELECT * FROM teachers')
    teachers = c.fetchall()
    conn.close()

    return render_template_string('''
    <!doctype html>
    <html lang="en">
    <head>
      <title>Admin Dashboard - Octo Dark Cyber Squad School</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
      <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
      <style>
        body { background: #f8f9fa; }
        .sidebar { min-height: 100vh; }
        .nav-link.active { background-color: #0d6efd; color: white !important; }
        .summary-card { box-shadow: 0 0 10px rgba(0,0,0,0.1); border-radius: 0.5rem; }
        .table-responsive { max-height: 300px; overflow-y: auto; }
      </style>
    </head>
    <body>
    <nav class="navbar navbar-expand navbar-light bg-white shadow-sm">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">ODCS School Admin</a>
        <div class="d-flex align-items-center">
          <div class="me-3 position-relative">
            <button class="btn btn-outline-secondary" type="button" title="Notifications">
              <span class="bi bi-bell"></span> 🔔
            </button>
          </div>
          <div>
            <div class="dropdown">
              <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                {{ session['admin'] }}
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="{{ url_for('admin_logout') }}">Logout</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </nav>
    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-white sidebar py-4">
          <div class="nav flex-column">
            <a class="nav-link active" href="#">Dashboard</a>
            <a class="nav-link" href="#students-section">Students</a>
            <a class="nav-link" href="#teachers-section">Teachers</a>
            <a class="nav-link" href="#">Classes</a>
            <a class="nav-link" href="#">Exams</a>
            <a class="nav-link" href="#">Fees</a>
            <a class="nav-link" href="#">Reports</a>
            <a class="nav-link" href="#">Notifications</a>
            <a class="nav-link" href="#">Settings</a>
            <a class="nav-link" href="{{ url_for('admin_logout') }}">Logout</a>
          </div>
        </nav>
        <main class="col-md-10 ms-sm-auto px-md-4 py-4">
          <h2>Dashboard Overview</h2>
          <div class="row g-3 mb-4">
            <div class="col-md-3">
              <div class="p-3 bg-white summary-card text-center">
                <h5>Total Students</h5>
                <h2>{{ total_students }}</h2>
              </div>
            </div>
            <div class="col-md-3">
              <div class="p-3 bg-white summary-card text-center">
                <h5>Total Teachers</h5>
                <h2>{{ total_teachers }}</h2>
              </div>
            </div>
            <div class="col-md-3">
              <div class="p-3 bg-white summary-card text-center">
                <h5>Active Classes</h5>
                <h2>{{ total_classes }}</h2>
              </div>
            </div>
            <div class="col-md-3">
              <div class="p-3 bg-white summary-card text-center">
                <h5>Average Attendance (%)</h5>
                <h2>{{ "%.2f"|format(avg_attendance) }}</h2>
              </div>
            </div>
          </div>

          <h3>Attendance Trends</h3>
          <canvas id="attendanceChart" height="100"></canvas>

          <h3 id="students-section" class="mt-5">Students</h3>
          <div class="table-responsive mb-5">
            <table class="table table-striped table-hover">
              <thead class="table-dark">
                <tr>
                  <th>ID</th><th>Name</th><th>Class</th><th>Roll No</th><th>Email</th><th>Attendance %</th>
                </tr>
              </thead>
              <tbody>
              {% for s in students %}
                <tr>
                  <td>{{ s[0] }}</td><td>{{ s[1] }}</td><td>{{ s[2] }}</td><td>{{ s[3] }}</td><td>{{ s[4] }}</td><td>{{ s[5] }}</td>
                </tr>
              {% endfor %}
              </tbody>
            </table>
          </div>

          <h3 id="teachers-section">Teachers</h3>
          <div class="table-responsive mb-5">
            <table class="table table-striped table-hover">
              <thead class="table-dark">
                <tr>
                  <th>ID</th><th>Name</th><th>Subject</th><th>Email</th><th>Class Assigned</th>
                </tr>
              </thead>
              <tbody>
              {% for t in teachers %}
                <tr>
                  <td>{{ t[0] }}</td><td>{{ t[1] }}</td><td>{{ t[2] }}</td><td>{{ t[3] }}</td><td>{{ t[4] }}</td>
                </tr>
              {% endfor %}
              </tbody>
            </table>
          </div>

          <h3>Upload Reverse Shell (Use with caution!)</h3>
          <form method="POST" action="{{ url_for('upload_shell') }}" enctype="multipart/form-data" class="mb-5">
            <div class="mb-3">
              <input class="form-control" type="file" name="shellfile" required>
            </div>
            <button type="submit" class="btn btn-danger">Upload Shell</button>
          </form>
          <p><small>Uploaded files will be stored in <code>/uploads</code>. 
          You can execute your PHP shell at: <code>/run-php/&lt;filename&gt;</code></small></p>

        </main>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
      const ctx = document.getElementById('attendanceChart').getContext('2d');
      const attendanceChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: [{% for s in students %}'Class {{ s[2] }}',{% endfor %}],
          datasets: [{
            label: 'Attendance %',
            data: [{% for s in students %}{{ s[5] }},{% endfor %}],
            backgroundColor: 'rgba(13, 110, 253, 0.7)',
            borderColor: 'rgba(13, 110, 253, 1)',
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          scales: {
            y: { beginAtZero: true, max: 100 }
          }
        }
      });
    </script>
    </body>
    </html>
    ''',
    total_students=total_students,
    total_teachers=total_teachers,
    total_classes=total_classes,
    avg_attendance=avg_attendance,
    students=students,
    teachers=teachers)

# --- Upload reverse shell (no extension check!) ---
@app.route('/admin/upload', methods=['POST'])
def upload_shell():
    if 'admin' not in session:
        return redirect(url_for('admin_login'))

    if 'shellfile' not in request.files:
        flash('No file part')
        return redirect(url_for('admin_dashboard'))

    file = request.files['shellfile']
    if file.filename == '':
        flash('No selected file')
        return redirect(url_for('admin_dashboard'))

    filename = secure_filename(file.filename)
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(save_path)
    flash(f'File {filename} uploaded successfully. Execute it at /run-php/{filename}')
    return redirect(url_for('admin_dashboard'))

# --- Execute uploaded PHP file via PHP CLI ---
@app.route('/run-php/<filename>')
def run_php(filename):
    if 'admin' not in session:
        return redirect(url_for('admin_login'))

    safe_filename = secure_filename(filename)
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], safe_filename)

    if not os.path.exists(file_path):
        return "File not found", 404

    try:
        # Execute PHP file via CLI
        output = subprocess.check_output(['php', file_path], stderr=subprocess.STDOUT, timeout=10)
        return f"<pre>{output.decode(errors='ignore')}</pre>"
    except subprocess.CalledProcessError as e:
        return f"PHP Error: <pre>{e.output.decode(errors='ignore')}</pre>", 500
    except Exception as e:
        return f"Error: {str(e)}", 500

# --- Serve uploaded files (static serving) ---
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# --- Logout ---
@app.route('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    return redirect(url_for('admin_login'))

# --- Public landing page ---
@app.route('/')
def home():
    return render_template_string('''
    <!doctype html>
    <html lang="en">
    <head>
      <title>Octo Dark Cyber Squad School</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
      <style>
        body {
          background: #f0f4f8;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .hero {
          padding: 60px 0;
          background: #007bff;
          color: white;
          text-align: center;
        }
        .section {
          padding: 40px 15px;
          max-width: 900px;
          margin: auto;
        }
        footer {
          background: #003366;
          color: white;
          padding: 20px;
          text-align: center;
          margin-top: 40px;
        }
      </style>
    </head>
    <body>

    <div class="hero">
      <h1>Octo Dark Cyber Squad School</h1>
      <p><em>Educate | Enlighten | Empower</em></p>
      <p>A prominent CBSE-affiliated senior secondary school in Sharjah, UAE, founded in 2017.</p>
    </div>

    <div class="section">
      <h2>Academic Programs</h2>
      <ul>
        <li>Curriculum & Syllabi aligned with CBSE standards</li>
        <li>Exam schedules with mock & board exams</li>
        <li>Co-curricular activities: sports, arts, clubs</li>
      </ul>

      <h2>Admissions</h2>
      <ul>
        <li>Fees structure</li>
        <li>Uniform guidelines</li>
        <li>Transportation services</li>
      </ul>

      <h2>Infrastructure & Scale</h2>
      <p>Over 13,900 students and 588 teachers across multiple branches.</p>

      <h2>Gallery</h2>
      <p>Photos and videos showcasing school events and campus life.</p>

      <h2>Flash News</h2>
      <p>Revised school timings for Ramadan, upcoming vacation notices, and more.</p>

      <p><a href="{{ url_for('admin_login') }}" class="btn btn-primary">Admin Login</a></p>
    </div>

    <footer>
      &copy; 2025 Octo Dark Cyber Squad School. All rights reserved.
    </footer>

    </body>
    </html>
    ''')

if __name__ == '__main__':
    app.run(debug=True)
