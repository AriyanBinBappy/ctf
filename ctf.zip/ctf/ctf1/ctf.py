from flask import Flask, request, redirect, render_template_string, session
import base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import secrets

app = Flask(__name__)
app.secret_key = "octo_dark_secret_key"

backend = default_backend()
KEY = b'octo_dark_cyber_secret_key_32bytes!!'[:32]

def pkcs7_pad(data: bytes) -> bytes:
    pad_len = 16 - (len(data) % 16)
    return data + bytes([pad_len] * pad_len)

def pkcs7_unpad(data: bytes) -> bytes:
    pad_len = data[-1]
    return data[:-pad_len]

def decrypt_flag(enc_b64: str) -> str:
    enc = base64.b64decode(enc_b64)
    iv = enc[:16]
    ct = enc[16:]
    cipher = Cipher(algorithms.AES(KEY), modes.CBC(iv), backend=backend)
    decryptor = cipher.decryptor()
    padded = decryptor.update(ct) + decryptor.finalize()
    return pkcs7_unpad(padded).decode()

encrypted_flag_b64 = "Zkz0Km9dy7+g8mIMcW7FYP9M+zDqLD6bbSLTbdnt54lfkCqVt8Xec5A=="

users = {
    1: {"username": "alice", "password": "alicepass", "account_type": "Savings", "balance": 10000, "branch": "Dhaka"},
    2: {"username": "bob", "password": "bobpass", "account_type": "Current", "balance": 5000, "branch": "Chittagong"},
    3: {"username": "carol", "password": "carolpass", "account_type": "Savings", "balance": 7500, "branch": "Khulna"},
    4: {"username": "david", "password": "davidpass", "account_type": "Current", "balance": 3000, "branch": "Sylhet"},
}

next_user_id = 5

branch_options = ["Dhaka", "Chattogram", "Khulna", "Rajshahi", "Barisal", "Sylhet", "Rangpur", "Mymensingh"]
account_types = ["Savings Account", "Current Account", "Fixed Deposit", "Student Account", "Salary Account", "Foreign Currency Account"]

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated_function

base_template = """
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Octo Dark Cyber Squad Bank</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
</head>
<body class='bg-dark text-white'>
    <div class='container mt-5'>
        {{ content|safe }}
    </div>
</body>
</html>
"""

@app.route("/")
def home():
    if "user_id" in session:
        return redirect("/account?id=" + str(session["user_id"]))
    return redirect("/login")

@app.route("/register", methods=["GET", "POST"])
def register():
    global next_user_id
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        account_type = request.form.get("account_type")
        balance = request.form.get("balance")
        branch = request.form.get("branch")

        if not (username and password and account_type and balance and branch):
            return "All fields required", 400
        try:
            balance = float(balance)
        except:
            return "Invalid balance", 400

        for u in users.values():
            if u["username"] == username:
                return "Username already exists", 400

        users[next_user_id] = {
            "username": username,
            "password": password,
            "account_type": account_type,
            "balance": balance,
            "branch": branch,
        }
        session["user_id"] = next_user_id
        next_user_id += 1
        return redirect("/login")

    content = """
    <h2 class='mb-4'>Register</h2>
    <form method='post'>
      <div class='mb-3'><input class='form-control' name='username' placeholder='Username' required></div>
      <div class='mb-3'><input class='form-control' name='password' type='password' placeholder='Password' required></div>
      <div class='mb-3'>
        <select class='form-select' name='account_type'>
          %s
        </select>
      </div>
      <div class='mb-3'><input class='form-control' name='balance' type='number' step='0.01' placeholder='Balance' required></div>
      <div class='mb-3'>
        <select class='form-select' name='branch'>
          %s
        </select>
      </div>
      <button class='btn btn-primary' type='submit'>Register</button>
    </form>
    <div class='mt-3'><a href='/login' class='text-info'>Already have an account? Login</a></div>
    """ % ("".join(f"<option value='{a}'>{a}</option>" for a in account_types), "".join(f"<option value='{b}'>{b}</option>" for b in branch_options))

    return render_template_string(base_template, content=content)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        for uid, user in users.items():
            if user["username"] == username and user["password"] == password:
                session["user_id"] = uid
                return redirect("/account?id=" + str(uid))
        return "Invalid credentials", 401

    content = """
    <h2 class='mb-4'>Login</h2>
    <form method='post'>
      <div class='mb-3'><input class='form-control' name='username' placeholder='Username' required></div>
      <div class='mb-3'><input class='form-control' name='password' type='password' placeholder='Password' required></div>
      <button class='btn btn-success' type='submit'>Login</button>
    </form>
    <div class='mt-3'><a href='/register' class='text-info'>Need an account? Register</a></div>
    """
    return render_template_string(base_template, content=content)

@app.route("/account")
@login_required
def account():
    user_id = request.args.get("id")
    try:
        user_id = int(user_id)
    except:
        return "Invalid user ID", 400

    if user_id == 17:
        flag = decrypt_flag(encrypted_flag_b64)
        return f"<h2 class='text-success'>Flag:</h2><pre>{flag}</pre>"

    user = users.get(user_id)
    if not user:
        return "User not found", 404

    content = f"""
    <h2 class='mb-4'>Welcome, {user['username']}</h2>
    <ul class='list-group'>
        <li class='list-group-item bg-dark text-white'>Account Type: {user['account_type']}</li>
        <li class='list-group-item bg-dark text-white'>Balance: {user['balance']:.2f} BDT</li>
        <li class='list-group-item bg-dark text-white'>Branch: {user['branch']}</li>
    </ul>
    <a href='/logout' class='btn btn-danger mt-3'>Logout</a>
    """
    return render_template_string(base_template, content=content)

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

if __name__ == "__main__":
    app.run(debug=True)
