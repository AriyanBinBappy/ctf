import os
import ast
import sys

def find_imports_in_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        tree = ast.parse(f.read(), filename=filepath)

    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for n in node.names:
                imports.add(n.name.split('.')[0])  # top-level module
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.add(node.module.split('.')[0])
    return imports

def scan_path_for_imports(path):
    all_imports = set()
    if os.path.isfile(path) and path.endswith('.py'):
        all_imports |= find_imports_in_file(path)
    elif os.path.isdir(path):
        for root, _, files in os.walk(path):
            for file in files:
                if file.endswith('.py'):
                    full_path = os.path.join(root, file)
                    all_imports |= find_imports_in_file(full_path)
    else:
        raise ValueError("Path must be a Python file or a directory containing Python files.")
    return all_imports

def get_stdlib_modules():
    stdlib = set(sys.builtin_module_names)
    common_stdlib = {
        'os', 'sys', 'json', 're', 'math', 'datetime', 'itertools', 'collections', 
        'functools', 'threading', 'subprocess', 'logging', 'pathlib', 'shutil', 'io',
        'ast', 'argparse', 'time', 'random', 'socket', 'enum', 'copy', 'types',
        'http', 'email', 'urllib', 'warnings', 'pickle', 'hashlib', 'csv', 'glob',
        'inspect', 'queue', 'traceback', 'tempfile', 'typing'
    }
    stdlib.update(common_stdlib)
    return stdlib

def save_requirements(modules, output_path):
    with open(output_path, 'w', encoding='utf-8') as f:
        for mod in sorted(modules):
            f.write(mod + '\n')
    print(f"Requirements saved to {output_path}")

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Generate requirements.txt from Python imports.")
    parser.add_argument("path", help="File or directory path to scan")
    parser.add_argument("-o", "--output", help="Output requirements.txt file path (optional)")
    args = parser.parse_args()

    imports = scan_path_for_imports(args.path)

    stdlib_modules = get_stdlib_modules()
    external_modules = {m for m in imports if m not in stdlib_modules}

    if not external_modules:
        print("No external dependencies found.")
    else:
        output_file = args.output
        if not output_file:
            # Save requirements.txt in the scanned folder or alongside the file
            if os.path.isdir(args.path):
                output_file = os.path.join(args.path, "requirements.txt")
            else:
                output_file = os.path.join(os.path.dirname(args.path), "requirements.txt")

        save_requirements(external_modules, output_file)
