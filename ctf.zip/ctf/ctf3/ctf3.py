from flask import Flask, request
import re

app = Flask(__name__)

# Fake student data (17 columns), flag in 4th column for id=30
students = {
    str(i): [
        i,
        f"Amit_{i}",
        "Class X",
        None, None, None, None, None, None,
        None, None, None, None, None, None, None, None
    ] for i in range(1, 50)
}

students["30"][3] = "ODCSCTF{uNi0n_b4s3d_byP@ssed}"

# Minimal WAF: block "union" or "select" unless bypassed by /**/ or /*!50000 ... */
FORBIDDEN = ["union", "select"]

def waf_filter(payload):
    lowered = payload.lower()
    cleaned = lowered.replace("/**/", "").replace("/*!50000", "").replace("*/", "")
    # Block if forbidden word present directly
    for word in FORBIDDEN:
        if word in lowered and word not in cleaned:
            return True
    return False

@app.route('/')
def homepage():
    return '''
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Octo Dark Cyber Squad School</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&family=Roboto&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body { font-family: 'Roboto', sans-serif; margin:0; background:#fff; color:#1B2A49; }
    nav.navbar {
      position: sticky; top: 0; z-index: 1000;
      background: rgba(27,42,73,0.8); transition: background 0.3s ease;
    }
    nav.navbar.scrolled { background: #1B2A49; }
    nav .navbar-brand { font-family: 'Poppins', sans-serif; font-weight: 700; color: #D4AF37; }
    nav .nav-link { color: white; font-weight: 500; }
    nav .nav-link:hover { color: #D4AF37; transition: color 0.3s; }
    .hero {
      height: 100vh;
      background: url('https://images.unsplash.com/photo-1596495578067-4c9ef2491822?auto=format&fit=crop&w=1470&q=80') center/cover no-repeat;
      display: flex; flex-direction: column; justify-content: center; align-items: center;
      color: white; text-shadow: 0 0 15px #000;
      text-align: center;
    }
    .hero h1 {
      font-family: 'Poppins', sans-serif;
      font-size: 3.5rem;
      animation: fadeIn 2s ease forwards;
      opacity: 0;
    }
    .hero p {
      font-size: 1.3rem;
      margin-bottom: 2rem;
      animation: fadeIn 2s ease 1s forwards;
      opacity: 0;
    }
    .btn-cta {
      background: #D4AF37; border: none; color: #1B2A49;
      padding: 0.75rem 2rem; font-weight: 700; border-radius: 5px;
      cursor: pointer; transition: background 0.3s ease;
    }
    .btn-cta:hover {
      background: #c49c2a;
    }
    .quick-stats {
      background: #f8f9fa; padding: 2rem 0; text-align: center;
      color: #1B2A49;
    }
    footer {
      background: #1B2A49; color: white; text-align: center; padding: 2rem 1rem;
    }
    footer form input[type="email"] {
      padding: 0.5rem;
      border-radius: 5px;
      border: none;
      margin-right: 0.5rem;
    }
    @keyframes fadeIn {
      to { opacity: 1; }
    }
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand" href="/">ODCS School</a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="/?id=home">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="/?id=about">About</a></li>
          <li class="nav-item"><a class="nav-link" href="/?id=academics">Academics</a></li>
          <li class="nav-item"><a class="nav-link" href="/?id=admissions">Admissions</a></li>
          <li class="nav-item"><a class="nav-link" href="/?id=activities">Activities</a></li>
          <li class="nav-item"><a class="nav-link" href="/?id=gallery">Gallery</a></li>
          <li class="nav-item"><a class="nav-link" href="/?id=news">News</a></li>
          <li class="nav-item"><a class="nav-link" href="/?id=contact">Contact</a></li>
          <li class="nav-item"><a class="nav-link" href="/student_info?id=1">Login</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="hero">
    <h1>Educate | Enlighten | Empower</h1>
    <p>Shaping Future Leaders Since 2017</p>
    <a href="/?id=apply"><button class="btn-cta">Apply Now</button></a>
  </div>
  <section class="quick-stats">
    <div class="container">
      <h3>Quick Stats</h3>
      <p>Students: 13,900+ | Teachers: 588 | Branches: Multiple | Established: 2017</p>
      <p>Managed by Indian Association Sharjah | Licensed by Sharjah Private Education Authority</p>
    </div>
  </section>
  <footer>
    <p>© 2025 Octo Dark Cyber Squad School</p>
    <form onsubmit="event.preventDefault(); alert('Subscribed! Thank you!');">
      <input type="email" placeholder="Your email" required />
      <button class="btn-cta" type="submit">Subscribe</button>
    </form>
  </footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Sticky navbar background toggle on scroll
    window.addEventListener('scroll', function () {
      const nav = document.querySelector('nav.navbar');
      if (window.scrollY > 50) nav.classList.add('scrolled');
      else nav.classList.remove('scrolled');
    });
  </script>
</body>
</html>
'''

@app.route('/student_info')
def student_info():
    payload = request.args.get('id', '')

    if waf_filter(payload):
        return "Blocked by WAF", 403

    payload_clean = payload.replace('/**/', '').replace('/*!50000', '').replace('*/', '').lower()

    if "from students" in payload_clean:
        # Attempt to extract the SELECT columns
        before_from = payload_clean.split("from students")[0]
        if "select" in before_from:
            cols_part = before_from.split("select")[-1].strip()
            columns = [c.strip() for c in cols_part.split(",")]
            if len(columns) == 17 and "flag" in cols_part:
                data = students.get("30")
                if data:
                    return f'''
<h1>Student Information</h1>
<ul>
  <li><strong>ID:</strong> {data[0]}</li>
  <li><strong>Name:</strong> {data[1]}</li>
  <li><strong>Class:</strong> {data[2]}</li>
</ul>
<!-- Flag (hidden in source): {data[3]} -->
<a href="/">Back to homepage</a>
'''
    return "Student not found or bad query", 404

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080)
